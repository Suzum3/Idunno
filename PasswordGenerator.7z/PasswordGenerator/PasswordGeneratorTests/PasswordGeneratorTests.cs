﻿using Moq;
using NUnit.Framework;
using PasswordGenerator;
namespace PasswordGeneratorTests;

[TestFixture]
public class PasswordGeneratorTests
{
    private PasswordGenerator.PasswordGenerator _cut;
    private Mock<IRandom> _randomMock;

    [SetUp]
    public void Setup()
    {
        _randomMock = new Mock<IRandom>();
        _cut = new PasswordGenerator.PasswordGenerator(_randomMock.Object);
    }

    [TestCase(0)]
    [TestCase(-7)]
    [TestCase(-99)]
    public void Generate_ShallThrowException_IfMinLengthIsSmallerThan_1(int minLength)
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => _cut.Generate(minLength, 10, false));
    }

    [TestCase(1)]
    [TestCase(6)]
    [TestCase(9)]
    public void Generate_ShallThrowException_IfMaxLengthIsSmallerThan_MinLength(int maxLength)
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => _cut.Generate(10, maxLength, false));
    }

    [TestCase(1, 2)]
    [TestCase(11, 23)]
    [TestCase(8, 15)]
    public void Generate_ShallNotThrowException_IfMinLengthAndMaxLength_AreValid(int minLength, int maxLength)
    {
        Assert.DoesNotThrow(
            () => _cut.Generate(minLength, maxLength, false));
    }

    [Test]
    public void Generate_ShallProducePassword_WithoutSpecialCharacters()
    {
        const int minLength = 3;
        const int maxLength = 8;

        SetupRandomToGeneratePasswordLengthEqualTo(minLength, maxLength, 4);
        SetupRandomToSelectCharactersAtIndexes(0, 1, 2, 3);

        var result = _cut.Generate(minLength, maxLength, false);

        Assert.That("ABCD" == result);
    }

    [Test]
    public void Generate_ShallProducePassword_WithSpecialCharacters()
    {
        const int minLength = 1;
        const int maxLength = 7;

        SetupRandomToGeneratePasswordLengthEqualTo(minLength, maxLength, 5);
        SetupRandomToSelectCharactersAtIndexes(7, 10, 18, 43, 48);

        var result = _cut.Generate(minLength, maxLength, true);

        Assert.That("HKS*+" == result);
    }

    private void SetupRandomToGeneratePasswordLengthEqualTo(int minLength, int maxLength, int passwordLengthToBeReturned)
    {
        _randomMock
            .Setup(mock => mock.Next(minLength, maxLength + 1))
            .Returns(passwordLengthToBeReturned);
    }

    private void SetupRandomToSelectCharactersAtIndexes(params int[] indexes)
    {
        var sequence = _randomMock.SetupSequence(mock => mock.Next(It.IsAny<int>()));

        foreach(var index in indexes)
        {
            sequence = sequence.Returns(index);
        }
    }
}